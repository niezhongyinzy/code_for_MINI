/**
 * Copyright (c) 2014 - 2020, Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 * Semiconductor ASA integrated circuit in a product or a software update for
 * such product, must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other
 * materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 * contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 * Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 * engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "nordic_common.h"
#include "nrf.h"
#include "ble_hci.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_conn_params.h"
#include "nrf_sdh.h"
#include "nrf_sdh_soc.h"
#include "nrf_sdh_ble.h"
#include "nrf_ble_gatt.h"
#include "nrf_ble_qwr.h"
#include "app_timer.h"
#include "ble_nus.h"
#include "app_uart.h"
#include "app_util_platform.h"
#include "bsp_btn_ble.h"
#include "nrf_pwr_mgmt.h"

#include "nrf_delay.h"
#include "bmm150.h"
#include "bmm150_defs.h"
#include "nrf_gpio.h"
#include "nrfx_twim.h"
#include "boards.h"
#if defined (UART_PRESENT)
#include "nrf_uart.h"
#endif
#if defined (UARTE_PRESENT)
#include "nrf_uarte.h"
#endif

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#define APP_BLE_CONN_CFG_TAG            1

#define DEVICE_NAME                     "Nordic_UART"
#define NUS_SERVICE_UUID_TYPE           BLE_UUID_TYPE_VENDOR_BEGIN

#define APP_BLE_OBSERVER_PRIO           3

#define APP_ADV_INTERVAL                64                                          /**< The advertising interval (in units of 0.625 ms. This value corresponds to 40 ms). */

#define APP_ADV_DURATION                18000                                       /**< The advertising duration (180 seconds) in units of 10 milliseconds. */

#define MIN_CONN_INTERVAL               MSEC_TO_UNITS(8, UNIT_1_25_MS)
#define MAX_CONN_INTERVAL               MSEC_TO_UNITS(12, UNIT_1_25_MS)
#define SLAVE_LATENCY                   40
#define CONN_SUP_TIMEOUT                MSEC_TO_UNITS(4000, UNIT_10_MS)             /**< Connection supervisory timeout (4 seconds), Supervision Timeout uses 10 ms units. */
#define FIRST_CONN_PARAMS_UPDATE_DELAY  APP_TIMER_TICKS(5000)                       /**< Time from initiating event (connect or start of notification) to first time sd_ble_gap_conn_param_update is called (5 seconds). */
#define NEXT_CONN_PARAMS_UPDATE_DELAY   APP_TIMER_TICKS(30000)                      /**< Time between each call to sd_ble_gap_conn_param_update after the first call (30 seconds). */
#define MAX_CONN_PARAMS_UPDATE_COUNT    3

#define DEAD_BEEF                       0xDEADBEEF

#define UART_TX_BUF_SIZE                1024
#define UART_RX_BUF_SIZE                1024

BLE_NUS_DEF(m_nus, NRF_SDH_BLE_TOTAL_LINK_COUNT);

NRF_BLE_GATT_DEF(m_gatt);
NRF_BLE_QWR_DEF(m_qwr);
BLE_ADVERTISING_DEF(m_advertising);

static uint16_t   m_conn_handle          = BLE_CONN_HANDLE_INVALID;
static uint16_t   m_ble_nus_max_data_len = BLE_GATT_ATT_MTU_DEFAULT - 3;             /**< Maximum length of data (in bytes) that can be transmitted to the peer by the Nordic UART service module. */
static ble_uuid_t m_adv_uuids[]          =
{
    {BLE_UUID_NUS_SERVICE, NUS_SERVICE_UUID_TYPE}
};

// A SoftDevice assertion requires a system reset to recover.
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}

static void gap_params_init(void)
{
    uint32_t                err_code;
    ble_gap_conn_params_t   gap_conn_params;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

    err_code = sd_ble_gap_device_name_set(&sec_mode,
                                          (const uint8_t *) DEVICE_NAME,
                                          strlen(DEVICE_NAME));
    APP_ERROR_CHECK(err_code);

    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
    APP_ERROR_CHECK(err_code);
}

static void nrf_qwr_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}

void ble_send(uint8_t * string,uint16_t length)
{

    uint32_t err_code;
    err_code = ble_nus_data_send(&m_nus,string,&length,m_conn_handle);

}

int multichannel(uint8_t dev_id, int channel);
int multiset0(uint8_t dev_id);
struct bmm150_dev bmm150_config_struct00;
struct bmm150_dev bmm150_config_struct01;
struct bmm150_dev bmm150_config_struct10;
struct bmm150_dev bmm150_config_struct11;
struct bmm150_dev bmm150_config_struct_ref;

static void nus_data_handler(ble_nus_evt_t * p_evt)
{

}

static void services_init(void)
{
    uint32_t           err_code;
    ble_nus_init_t     nus_init;
    nrf_ble_qwr_init_t qwr_init = {0};

    qwr_init.error_handler = nrf_qwr_error_handler;

    err_code = nrf_ble_qwr_init(&m_qwr, &qwr_init);
    APP_ERROR_CHECK(err_code);

    memset(&nus_init, 0, sizeof(nus_init));

    nus_init.data_handler = nus_data_handler;

    err_code = ble_nus_init(&m_nus, &nus_init);
    APP_ERROR_CHECK(err_code);
}

static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{
    uint32_t err_code;

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)
    {
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }
}

static void conn_params_error_handler(uint32_t nrf_error)
{
  if(NRF_ERROR_INVALID_STATE == nrf_error)
  return;

}

static void conn_params_init(void)
{
    uint32_t               err_code;
    ble_conn_params_init_t cp_init;

    memset(&cp_init, 0, sizeof(cp_init));

    cp_init.p_conn_params                  = NULL;
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;
    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;
    cp_init.disconnect_on_fail             = false;
    cp_init.evt_handler                    = on_conn_params_evt;
    cp_init.error_handler                  = conn_params_error_handler;

    err_code = ble_conn_params_init(&cp_init);
    APP_ERROR_CHECK(err_code);
}

static void sleep_mode_enter(void)
{
    uint32_t err_code = bsp_indication_set(BSP_INDICATE_IDLE);
    APP_ERROR_CHECK(err_code);

    err_code = bsp_btn_ble_sleep_mode_prepare();
    APP_ERROR_CHECK(err_code);

    // Go to system-off mode (this function will not return; wakeup will cause a reset).
    err_code = sd_power_system_off();
    APP_ERROR_CHECK(err_code);
}

static void on_adv_evt(ble_adv_evt_t ble_adv_evt)
{
    uint32_t err_code;

    switch (ble_adv_evt)
    {
        case BLE_ADV_EVT_FAST:
            err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
            APP_ERROR_CHECK(err_code);
            break;
        case BLE_ADV_EVT_IDLE:
            sleep_mode_enter();
            break;
        default:
            break;
    }
}

static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context)
{
    uint32_t err_code;

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_CONNECTED:
            NRF_LOG_INFO("Connected");
            err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
            APP_ERROR_CHECK(err_code);
            m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
            err_code = nrf_ble_qwr_conn_handle_assign(&m_qwr, m_conn_handle);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GAP_EVT_DISCONNECTED:
            NRF_LOG_INFO("Disconnected");

            m_conn_handle = BLE_CONN_HANDLE_INVALID;
            break;

        case BLE_GAP_EVT_PHY_UPDATE_REQUEST:
        {
            NRF_LOG_DEBUG("PHY update request.");
            ble_gap_phys_t const phys =
            {
                .rx_phys = BLE_GAP_PHY_AUTO,
                .tx_phys = BLE_GAP_PHY_AUTO,
            };
            err_code = sd_ble_gap_phy_update(p_ble_evt->evt.gap_evt.conn_handle, &phys);
            APP_ERROR_CHECK(err_code);
        } break;

        case BLE_GAP_EVT_SEC_PARAMS_REQUEST:
            // Pairing not supported
            err_code = sd_ble_gap_sec_params_reply(m_conn_handle, BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP, NULL, NULL);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GATTS_EVT_SYS_ATTR_MISSING:
            // No system attributes have been stored.
            err_code = sd_ble_gatts_sys_attr_set(m_conn_handle, NULL, 0, 0);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GATTC_EVT_TIMEOUT:

            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gattc_evt.conn_handle,
                                             BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GATTS_EVT_TIMEOUT:

            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gatts_evt.conn_handle,
                                             BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
            break;

        default:

            break;
    }
}

static void ble_stack_init(void)
{
    ret_code_t err_code;

    err_code = nrf_sdh_enable_request();
    APP_ERROR_CHECK(err_code);

    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_sdh_ble_enable(&ram_start);
    APP_ERROR_CHECK(err_code);

    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}

void gatt_evt_handler(nrf_ble_gatt_t * p_gatt, nrf_ble_gatt_evt_t const * p_evt)
{
    if ((m_conn_handle == p_evt->conn_handle) && (p_evt->evt_id == NRF_BLE_GATT_EVT_ATT_MTU_UPDATED))
    {
        m_ble_nus_max_data_len = p_evt->params.att_mtu_effective - OPCODE_LENGTH - HANDLE_LENGTH;
        NRF_LOG_INFO("Data len is set to 0x%X(%d)", m_ble_nus_max_data_len, m_ble_nus_max_data_len);
    }
    NRF_LOG_DEBUG("ATT MTU exchange completed. central 0x%x peripheral 0x%x",
                  p_gatt->att_mtu_desired_central,
                  p_gatt->att_mtu_desired_periph);
}

void gatt_init(void)
{
    ret_code_t err_code;

    err_code = nrf_ble_gatt_init(&m_gatt, gatt_evt_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_gatt_att_mtu_periph_set(&m_gatt, NRF_SDH_BLE_GATT_MAX_MTU_SIZE);
    APP_ERROR_CHECK(err_code);
}

void bsp_event_handler(bsp_event_t event)
{
    uint32_t err_code;
    switch (event)
    {
        case BSP_EVENT_SLEEP:
            sleep_mode_enter();
            break;

        case BSP_EVENT_DISCONNECT:
            err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            if (err_code != NRF_ERROR_INVALID_STATE)
            {
                APP_ERROR_CHECK(err_code);
            }
            break;

        case BSP_EVENT_WHITELIST_OFF:
            if (m_conn_handle == BLE_CONN_HANDLE_INVALID)
            {
                err_code = ble_advertising_restart_without_whitelist(&m_advertising);
                if (err_code != NRF_ERROR_INVALID_STATE)
                {
                    APP_ERROR_CHECK(err_code);
                }
            }
            break;

        default:
            break;
    }
}

void uart_event_handle(app_uart_evt_t * p_event)
{
    static uint8_t data_array[BLE_NUS_MAX_DATA_LEN];
    static uint8_t index = 0;
    uint32_t       err_code;

    switch (p_event->evt_type)
    {
        case APP_UART_DATA_READY:
            UNUSED_VARIABLE(app_uart_get(&data_array[index]));
            index++;

            if ((data_array[index - 1] == '\n') ||
                (data_array[index - 1] == '\r') ||
                (index >= m_ble_nus_max_data_len))
            {
                if (index > 1)
                {
                    NRF_LOG_DEBUG("Ready to send data over BLE NUS");
                    NRF_LOG_HEXDUMP_DEBUG(data_array, index);

                    do
                    {
                        uint16_t length = (uint16_t)index;
                        err_code = ble_nus_data_send(&m_nus, data_array, &length, m_conn_handle);
                        if ((err_code != NRF_ERROR_INVALID_STATE) &&
                            (err_code != NRF_ERROR_RESOURCES) &&
                            (err_code != NRF_ERROR_NOT_FOUND))
                        {
                            APP_ERROR_CHECK(err_code);
                        }
                    } while (err_code == NRF_ERROR_RESOURCES);
                }

                index = 0;
            }
            break;

        case APP_UART_COMMUNICATION_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_communication);
            break;

        case APP_UART_FIFO_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_code);
            break;

        default:
            break;
    }
}

static void uart_init(void)
{
    uint32_t                     err_code;
    app_uart_comm_params_t const comm_params =
    {
        .rx_pin_no    = RX_PIN_NUMBER,
        .tx_pin_no    = TX_PIN_NUMBER,
        .rts_pin_no   = RTS_PIN_NUMBER,
        .cts_pin_no   = CTS_PIN_NUMBER,
        .flow_control = APP_UART_FLOW_CONTROL_DISABLED,
        .use_parity   = false,
#if defined (UART_PRESENT)
        .baud_rate    = NRF_UART_BAUDRATE_115200
#else
        .baud_rate    = NRF_UARTE_BAUDRATE_115200
#endif
    };

    APP_UART_FIFO_INIT(&comm_params,
                       UART_RX_BUF_SIZE,
                       UART_TX_BUF_SIZE,
                       uart_event_handle,
                       APP_IRQ_PRIORITY_LOWEST,
                       err_code);
    APP_ERROR_CHECK(err_code);
}

static void advertising_init(void)
{
    uint32_t               err_code;
    ble_advertising_init_t init;

    memset(&init, 0, sizeof(init));

    init.advdata.name_type          = BLE_ADVDATA_FULL_NAME;
    init.advdata.include_appearance = false;
    init.advdata.flags              = BLE_GAP_ADV_FLAGS_LE_ONLY_LIMITED_DISC_MODE;

    init.srdata.uuids_complete.uuid_cnt = sizeof(m_adv_uuids) / sizeof(m_adv_uuids[0]);
    init.srdata.uuids_complete.p_uuids  = m_adv_uuids;

    init.config.ble_adv_fast_enabled  = true;
    init.config.ble_adv_fast_interval = APP_ADV_INTERVAL;
    init.config.ble_adv_fast_timeout  = APP_ADV_DURATION;
    init.evt_handler = on_adv_evt;

    err_code = ble_advertising_init(&m_advertising, &init);
    APP_ERROR_CHECK(err_code);

    ble_advertising_conn_cfg_tag_set(&m_advertising, APP_BLE_CONN_CFG_TAG);
}

static void buttons_leds_init(bool * p_erase_bonds)
{
    bsp_event_t startup_event;

    uint32_t err_code = bsp_init(BSP_INIT_LEDS | BSP_INIT_BUTTONS, bsp_event_handler);
    APP_ERROR_CHECK(err_code);

    err_code = bsp_btn_ble_init(NULL, &startup_event);
    APP_ERROR_CHECK(err_code);

    *p_erase_bonds = (startup_event == BSP_EVENT_CLEAR_BONDING_DATA);
}

static void log_init(void)
{
    ret_code_t err_code = NRF_LOG_INIT(NULL);
    APP_ERROR_CHECK(err_code);

    NRF_LOG_DEFAULT_BACKENDS_INIT();
}

static void power_management_init(void)
{
    ret_code_t err_code;
    err_code = nrf_pwr_mgmt_init();
    APP_ERROR_CHECK(err_code);
}

static void idle_state_handle(void)
{
    if (NRF_LOG_PROCESS() == false)
    {
        nrf_pwr_mgmt_run();
    }
}

static void advertising_start(void)
{
    uint32_t err_code = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);
    APP_ERROR_CHECK(err_code);
}

#define TWI_INSTANCE_ID     0
#define TWI_INSTANCE_ID_REF 1
//TWI transfer-completion flag.
static volatile bool m_xfer_done_arr = false;
static volatile bool m_xfer_done_ref = false;

static const nrfx_twim_t shili = NRFX_TWIM_INSTANCE(TWI_INSTANCE_ID);
static const nrfx_twim_t shili_ref = NRFX_TWIM_INSTANCE(TWI_INSTANCE_ID_REF);

void twi_handler_arr(nrfx_twim_evt_t const * p_event, void * p_context)
{
    if (p_event->type == NRFX_TWIM_EVT_DONE) {
        m_xfer_done_arr = true;
    }
}

void twi_handler_ref(nrfx_twim_evt_t const * p_event, void * p_context)
{
    if (p_event->type == NRFX_TWIM_EVT_DONE) {
        m_xfer_done_ref = true;
    }
}

void twi_mast_init(void)
{
    ret_code_t err_code;

    const nrfx_twim_config_t twi_config = {
       .scl                = 25,  //Define the TWI SCL pin.
       .sda                = 27,  //Define the TWI SDA pin.
       .frequency          = NRF_TWIM_FREQ_400K,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
       .hold_bus_uninit    = false
    };

    err_code = nrfx_twim_init(&shili, &twi_config, twi_handler_arr, NULL);

    APP_ERROR_CHECK(err_code);

    nrfx_twim_enable(&shili);
}

void twi_mast_init_ref(void)
{
    ret_code_t err_code;

    const nrfx_twim_config_t twi_config = {
       .scl                = 29,  //Define the TWI SCL pin.
       .sda                = 28,  //Define the TWI SDA pin.
       .frequency          = NRF_TWIM_FREQ_400K,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
       .hold_bus_uninit    = false
    };

    err_code = nrfx_twim_init(&shili_ref, &twi_config, twi_handler_ref, NULL);

    APP_ERROR_CHECK(err_code);

    nrfx_twim_enable(&shili_ref);
}

int8_t reeaad_ref(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t length){
      ret_code_t err_code;

        m_xfer_done_ref = false;

      err_code = nrfx_twim_tx(&shili_ref, dev_id, &reg_addr, 1, true);

        for(int i=1; i<=5000; i++){
          if(m_xfer_done_ref==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
    if (NRF_SUCCESS != err_code)
    {
        return 1;
    }

        m_xfer_done_ref = false;

      err_code = nrfx_twim_rx(&shili_ref, dev_id, reg_data, length);

        for(int i=1; i<=5000; i++){
          if(m_xfer_done_ref==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
        if (NRF_SUCCESS != err_code)
    {
        return 1;
    }
        return 0;
}

int8_t wriiite_ref(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t length){
      ret_code_t err_code;
      uint8_t tx_buf[2];

        tx_buf[0] = reg_addr;
    tx_buf[1] = *reg_data;

        m_xfer_done_ref = false;

    err_code = nrfx_twim_tx(&shili_ref, dev_id, tx_buf, 2, false);

        for(int i=1; i<=5000; i++){
          if(m_xfer_done_ref==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
      if (NRF_SUCCESS != err_code)
    {
        return 1;
    }
        return 0;
}
int8_t reeaad(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t length){
      ret_code_t err_code;

        m_xfer_done_arr = false;

      err_code = nrfx_twim_tx(&shili, dev_id, &reg_addr, 1, true);

      for(int i=1; i<=50000; i++){
          if(m_xfer_done_arr==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
    if (NRF_SUCCESS != err_code)
    {
        return 1;
    }

        m_xfer_done_arr = false;

      err_code = nrfx_twim_rx(&shili, dev_id, reg_data, length);

        for(int i=1; i<=5000; i++){
          if(m_xfer_done_arr==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
        if (NRF_SUCCESS != err_code)
    {
        return 1;
    }
        return 0;
}

int8_t wriiite(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t length){
      ret_code_t err_code;
      uint8_t tx_buf[2];

        tx_buf[0] = reg_addr;
    tx_buf[1] = *reg_data;

        m_xfer_done_arr = false;

    err_code = nrfx_twim_tx(&shili, dev_id, tx_buf, 2, false);

        for(int i=1; i<=5000; i++){
          if(m_xfer_done_arr==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
      if (NRF_SUCCESS != err_code)
    {
        return 1;
    }
        return 0;
}

int multichannel(uint8_t dev_id, int channel){
      ret_code_t err_code;
      uint8_t tx_buf[2];
      uint8_t buf=1<<channel;

        m_xfer_done_arr = false;

    err_code = nrfx_twim_tx(&shili, dev_id, &buf, 1, false);

        for(int i=1; i<=5000; i++){
          if(m_xfer_done_arr==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
      if (NRF_SUCCESS != err_code)
    {
        return 1;
    }
        return 0;
}

int multiset0(uint8_t dev_id){
      ret_code_t err_code;
      uint8_t tx_buf[2];
      uint8_t buf=0;

        m_xfer_done_arr = false;

    err_code = nrfx_twim_tx(&shili, dev_id, &buf, 1, false);

        for(int i=1; i<=5000; i++){
          if(m_xfer_done_arr==false) {
                nrf_delay_us(1);
            }else{
                break;
            }
        }
      if (NRF_SUCCESS != err_code)
    {
        return 1;
    }
        return 0;
}

void user_delay_us(uint32_t period, void *intf_ptr){
    nrf_delay_us(period);
}

int8_t read_sensor_data(struct bmm150_dev *dev)
{
    int8_t rslt;

    rslt = bmm150_read_mag_data(dev);

    return rslt;
}

int8_t perform_self_tests(struct bmm150_dev *dev)
{
    int8_t rslt;

    rslt = bmm150_perform_self_test(BMM150_NORMAL_SELF_TEST, dev);
    printf("\n NORMAL SELF TEST RESULT :  %d",rslt);

    if (rslt == BMM150_OK) {
        printf("\n Normal Self test passed ");
    } else {
        printf("\n Normal Self test failed ");
    }

    rslt |= bmm150_perform_self_test(BMM150_ADVANCED_SELF_TEST, dev);
    printf("\n ADVANCED SELF TEST RESULT : %d",rslt);

    if (rslt == BMM150_OK) {
        printf("\n Advanced Self test passed ");
    } else {
        printf("\n Advanced Self test failed ");
    }

    return rslt;
}

void set_param_ref(){
        bmm150_config_struct_ref.chip_id = 0x32;
      bmm150_config_struct_ref.dev_id = BMM150_DEFAULT_I2C_ADDRESS;
      bmm150_config_struct_ref.intf=BMM150_I2C_INTF;
      bmm150_config_struct_ref.delay_ms=nrf_delay_ms;
      bmm150_config_struct_ref.read=reeaad_ref;
      bmm150_config_struct_ref.write=wriiite_ref;

}
void set_param_00(){
        bmm150_config_struct00.chip_id = 0x32;
      bmm150_config_struct00.dev_id = BMM150_DEFAULT_I2C_ADDRESS;
      bmm150_config_struct00.intf=BMM150_I2C_INTF;
      bmm150_config_struct00.delay_ms=nrf_delay_ms;
      bmm150_config_struct00.read=reeaad;
      bmm150_config_struct00.write=wriiite;

}
void set_param_01(){
        bmm150_config_struct01.chip_id = 0x32;
      bmm150_config_struct01.dev_id = BMM150_I2C_ADDRESS_CSB_LOW_SDO_HIGH;
      bmm150_config_struct01.intf=BMM150_I2C_INTF;
      bmm150_config_struct01.delay_ms=nrf_delay_ms;
      bmm150_config_struct01.read=reeaad;
      bmm150_config_struct01.write=wriiite;

}
void set_param_10(){
        bmm150_config_struct10.chip_id = 0x32;
      bmm150_config_struct10.dev_id = BMM150_I2C_ADDRESS_CSB_HIGH_SDO_LOW;
      bmm150_config_struct10.intf=BMM150_I2C_INTF;
      bmm150_config_struct10.delay_ms=nrf_delay_ms;
      bmm150_config_struct10.read=reeaad;
      bmm150_config_struct10.write=wriiite;

}
void set_param_11(){
        bmm150_config_struct11.chip_id = 0x32;
      bmm150_config_struct11.dev_id = BMM150_I2C_ADDRESS_CSB_HIGH_SDO_HIGH;
      bmm150_config_struct11.intf=BMM150_I2C_INTF;
      bmm150_config_struct11.delay_ms=nrf_delay_ms;
      bmm150_config_struct11.read=reeaad;
      bmm150_config_struct11.write=wriiite;

}
void set_forced(){
        bmm150_config_struct_ref.settings.pwr_mode = BMM150_FORCED_MODE;
        bmm150_config_struct00.settings.pwr_mode = BMM150_FORCED_MODE;
        bmm150_config_struct01.settings.pwr_mode = BMM150_FORCED_MODE;
        bmm150_config_struct10.settings.pwr_mode = BMM150_FORCED_MODE;
        bmm150_config_struct11.settings.pwr_mode = BMM150_FORCED_MODE;
}
void set_suspend(){
        bmm150_config_struct_ref.settings.pwr_mode = BMM150_SUSPEND_MODE;
        bmm150_config_struct00.settings.pwr_mode = BMM150_SUSPEND_MODE;
        bmm150_config_struct01.settings.pwr_mode = BMM150_SUSPEND_MODE;
        bmm150_config_struct10.settings.pwr_mode = BMM150_SUSPEND_MODE;
        bmm150_config_struct11.settings.pwr_mode = BMM150_SUSPEND_MODE;
}
void set_sleep(){
        bmm150_config_struct_ref.settings.pwr_mode = BMM150_SLEEP_MODE;
        bmm150_config_struct00.settings.pwr_mode = BMM150_SLEEP_MODE;
        bmm150_config_struct01.settings.pwr_mode = BMM150_SLEEP_MODE;
        bmm150_config_struct10.settings.pwr_mode = BMM150_SLEEP_MODE;
        bmm150_config_struct11.settings.pwr_mode = BMM150_SLEEP_MODE;
}
void gemini_wake(){
        uint8_t power_on_cmd = 0x01; // Write to register 0x4B to enter Sleep mode directly.
        // Wake all 32 array sensors.
        for(int p=0; p<=7; p++){
                multichannel(0x70, p);
                wriiite(bmm150_config_struct00.dev_id, 0x4B, &power_on_cmd, 1);
                wriiite(bmm150_config_struct01.dev_id, 0x4B, &power_on_cmd, 1);
                wriiite(bmm150_config_struct10.dev_id, 0x4B, &power_on_cmd, 1);
                wriiite(bmm150_config_struct11.dev_id, 0x4B, &power_on_cmd, 1);
                multiset0(0x70);
    }
        // Wake the reference sensor.
        wriiite_ref(bmm150_config_struct_ref.dev_id, 0x4B, &power_on_cmd, 1);

        bmm150_config_struct_ref.settings.pwr_cntrl_bit = BMM150_POWER_CNTRL_ENABLE;
    bmm150_config_struct00.settings.pwr_cntrl_bit = BMM150_POWER_CNTRL_ENABLE;
    bmm150_config_struct01.settings.pwr_cntrl_bit = BMM150_POWER_CNTRL_ENABLE;
    bmm150_config_struct10.settings.pwr_cntrl_bit = BMM150_POWER_CNTRL_ENABLE;
    bmm150_config_struct11.settings.pwr_cntrl_bit = BMM150_POWER_CNTRL_ENABLE;
}
void gemini_suspend(void)
{
    uint8_t suspend_cmd = 0x00;   // 0x4B power control bit = 0

    for (int p = 0; p <= 7; p++) {
        multichannel(0x70, p);
        wriiite(bmm150_config_struct00.dev_id, 0x4B, &suspend_cmd, 1);
        wriiite(bmm150_config_struct01.dev_id, 0x4B, &suspend_cmd, 1);
        wriiite(bmm150_config_struct10.dev_id, 0x4B, &suspend_cmd, 1);
        wriiite(bmm150_config_struct11.dev_id, 0x4B, &suspend_cmd, 1);
        multiset0(0x70);
    }
    wriiite_ref(bmm150_config_struct_ref.dev_id, 0x4B, &suspend_cmd, 1);

    bmm150_config_struct_ref.settings.pwr_cntrl_bit = BMM150_POWER_CNTRL_DISABLE;
    bmm150_config_struct00.settings.pwr_cntrl_bit   = BMM150_POWER_CNTRL_DISABLE;
    bmm150_config_struct01.settings.pwr_cntrl_bit   = BMM150_POWER_CNTRL_DISABLE;
    bmm150_config_struct10.settings.pwr_cntrl_bit   = BMM150_POWER_CNTRL_DISABLE;
    bmm150_config_struct11.settings.pwr_cntrl_bit   = BMM150_POWER_CNTRL_DISABLE;
}
void bmm150_full_init_all(void)
{

    // Initialize 32 sensors across the 8 multiplexer channels.
    for (int p = 0; p <= 7; p++) {
        multichannel(0x70, p);

        bmm150_init(&bmm150_config_struct00);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct00);

        bmm150_init(&bmm150_config_struct01);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct01);

        bmm150_init(&bmm150_config_struct10);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct10);

        bmm150_init(&bmm150_config_struct11);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct11);

        multiset0(0x70);
    }

    bmm150_init(&bmm150_config_struct_ref);
    bmm150_set_nzy_forced_50_63(&bmm150_config_struct_ref);
}

void set_all_op_mode(){
    for(int p=0;p<=7;p++){
        multichannel(0x70,p);
        bmm150_set_op_mode(&bmm150_config_struct00);
        bmm150_set_op_mode(&bmm150_config_struct01);
        bmm150_set_op_mode(&bmm150_config_struct10);
        bmm150_set_op_mode(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_op_mode(&bmm150_config_struct_ref);
}
void set_all_rep_200_250()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_200_250(&bmm150_config_struct00);
        bmm150_set_nzy_forced_200_250(&bmm150_config_struct01);
        bmm150_set_nzy_forced_200_250(&bmm150_config_struct10);
        bmm150_set_nzy_forced_200_250(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_200_250(&bmm150_config_struct_ref);
}

void set_all_rep_160_200()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_160_200(&bmm150_config_struct00);
        bmm150_set_nzy_forced_160_200(&bmm150_config_struct01);
        bmm150_set_nzy_forced_160_200(&bmm150_config_struct10);
        bmm150_set_nzy_forced_160_200(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_160_200(&bmm150_config_struct_ref);
}
void set_all_rep_120_150()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_120_150(&bmm150_config_struct00);
        bmm150_set_nzy_forced_120_150(&bmm150_config_struct01);
        bmm150_set_nzy_forced_120_150(&bmm150_config_struct10);
        bmm150_set_nzy_forced_120_150(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_120_150(&bmm150_config_struct_ref);
}
void set_all_rep_100_125()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_100_125(&bmm150_config_struct00);
        bmm150_set_nzy_forced_100_125(&bmm150_config_struct01);
        bmm150_set_nzy_forced_100_125(&bmm150_config_struct10);
        bmm150_set_nzy_forced_100_125(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_100_125(&bmm150_config_struct_ref);
}

void set_all_rep_50_63()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct00);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct01);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct10);
        bmm150_set_nzy_forced_50_63(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_50_63(&bmm150_config_struct_ref);
}

void set_all_rep_25_32()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_25_32(&bmm150_config_struct00);
        bmm150_set_nzy_forced_25_32(&bmm150_config_struct01);
        bmm150_set_nzy_forced_25_32(&bmm150_config_struct10);
        bmm150_set_nzy_forced_25_32(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_25_32(&bmm150_config_struct_ref);
}
void set_all_rep_20_25()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_20_25(&bmm150_config_struct00);
        bmm150_set_nzy_forced_20_25(&bmm150_config_struct01);
        bmm150_set_nzy_forced_20_25(&bmm150_config_struct10);
        bmm150_set_nzy_forced_20_25(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_20_25(&bmm150_config_struct_ref);
}
void set_all_rep_13_16()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_13_16(&bmm150_config_struct00);
        bmm150_set_nzy_forced_13_16(&bmm150_config_struct01);
        bmm150_set_nzy_forced_13_16(&bmm150_config_struct10);
        bmm150_set_nzy_forced_13_16(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_13_16(&bmm150_config_struct_ref);
}

void set_all_rep_6_8()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_6_8(&bmm150_config_struct00);
        bmm150_set_nzy_forced_6_8(&bmm150_config_struct01);
        bmm150_set_nzy_forced_6_8(&bmm150_config_struct10);
        bmm150_set_nzy_forced_6_8(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_6_8(&bmm150_config_struct_ref);
}

void set_all_rep_3_4()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_3_4(&bmm150_config_struct00);
        bmm150_set_nzy_forced_3_4(&bmm150_config_struct01);
        bmm150_set_nzy_forced_3_4(&bmm150_config_struct10);
        bmm150_set_nzy_forced_3_4(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_3_4(&bmm150_config_struct_ref);
}

void set_all_rep_2_2()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_2_2(&bmm150_config_struct00);
        bmm150_set_nzy_forced_2_2(&bmm150_config_struct01);
        bmm150_set_nzy_forced_2_2(&bmm150_config_struct10);
        bmm150_set_nzy_forced_2_2(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_2_2(&bmm150_config_struct_ref);
}

void set_all_rep_1_1()
{
    for(int p=0; p<=7; p++){
        multichannel(0x70, p);
        bmm150_set_nzy_forced_1_1(&bmm150_config_struct00);
        bmm150_set_nzy_forced_1_1(&bmm150_config_struct01);
        bmm150_set_nzy_forced_1_1(&bmm150_config_struct10);
        bmm150_set_nzy_forced_1_1(&bmm150_config_struct11);
        multiset0(0x70);
    }
    bmm150_set_nzy_forced_1_1(&bmm150_config_struct_ref);
}

void timer_timeout_handler(void * p_context);
APP_TIMER_DEF(m_timer1);

static void timers_init(void)
{

    uint32_t err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_timer1, APP_TIMER_MODE_REPEATED, timer_timeout_handler);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_start(m_timer1, APP_TIMER_TICKS(250), NULL);
    APP_ERROR_CHECK(err_code);
}

static bool m_is_first_boot = true;
int samplecount=0;
int roundd=0;
void timer_timeout_handler(void * p_context)
{

            int16_t resultprint[99]={0};
            set_all_op_mode();

            // Wait for data-ready status before reading sensor data.

            uint8_t drdy_status = 0;
            uint32_t timeout_safety = 0;

            do {

                    reeaad_ref(bmm150_config_struct_ref.dev_id, 0x48, &drdy_status, 1);

                    // Check bit 0 (the DRDY bit).
                    if (drdy_status & 0x01) {
                            break;
                    }

                    nrf_delay_us(2000);
                    timeout_safety++;
            } while (timeout_safety < 150); // Timeout protection.
            nrf_delay_us(100);

            // Read sensor data and encode it as int16_t values.

            bmm150_read_mag_data(&bmm150_config_struct_ref);
            resultprint[96] = (int16_t)(bmm150_config_struct_ref.data.x * 10.0f);
            resultprint[97] = (int16_t)(bmm150_config_struct_ref.data.y * 10.0f);
            resultprint[98] = (int16_t)(bmm150_config_struct_ref.data.z * 10.0f);
            for(int p=0;p<=7;p++){
                    multichannel(0x70,p);

                    bmm150_read_mag_data(&bmm150_config_struct00);
                    // Multiply by 10.0f to preserve one decimal place, then cast to int16.
                    resultprint[0+12*p] = (int16_t)((bmm150_config_struct00.data.x - bmm150_config_struct_ref.data.x) * 10.0f);
                    resultprint[1+12*p] = (int16_t)((bmm150_config_struct00.data.y - bmm150_config_struct_ref.data.y) * 10.0f);
                    resultprint[2+12*p] = (int16_t)((bmm150_config_struct00.data.z - bmm150_config_struct_ref.data.z) * 10.0f);

                    bmm150_read_mag_data(&bmm150_config_struct01);
                    resultprint[3+12*p] = (int16_t)((bmm150_config_struct01.data.x - bmm150_config_struct_ref.data.x) * 10.0f);
                    resultprint[4+12*p] = (int16_t)((bmm150_config_struct01.data.y - bmm150_config_struct_ref.data.y) * 10.0f);
                    resultprint[5+12*p] = (int16_t)((bmm150_config_struct01.data.z - bmm150_config_struct_ref.data.z) * 10.0f);

                    bmm150_read_mag_data(&bmm150_config_struct10);
                    resultprint[6+12*p] = (int16_t)((bmm150_config_struct10.data.x - bmm150_config_struct_ref.data.x) * 10.0f);
                    resultprint[7+12*p] = (int16_t)((bmm150_config_struct10.data.y - bmm150_config_struct_ref.data.y) * 10.0f);
                    resultprint[8+12*p] = (int16_t)((bmm150_config_struct10.data.z - bmm150_config_struct_ref.data.z) * 10.0f);

                    bmm150_read_mag_data(&bmm150_config_struct11);
                    resultprint[9+12*p] = (int16_t)((bmm150_config_struct11.data.x - bmm150_config_struct_ref.data.x) * 10.0f);
                    resultprint[10+12*p]= (int16_t)((bmm150_config_struct11.data.y - bmm150_config_struct_ref.data.y) * 10.0f);
                    resultprint[11+12*p]= (int16_t)((bmm150_config_struct11.data.z - bmm150_config_struct_ref.data.z) * 10.0f);

                    multiset0(0x70);
            }

            // Send the binary data in a single BLE packet.

            uint8_t * p_data = (uint8_t *)resultprint;

            // Calculate the transmission length: 99 values * 2 bytes = 198 bytes.

            uint16_t total_length = 99 * sizeof(int16_t);

            ble_send(p_data, total_length);

}

int main(void)
{
    bool erase_bonds;

      twi_mast_init();
      twi_mast_init_ref();
    //Delay before starting services after power-on to avoid possible data errors.
      nrf_delay_ms(2000);

    buttons_leds_init(&erase_bonds);
    power_management_init();
    ble_stack_init();
    gap_params_init();
    gatt_init();
    services_init();
    advertising_init();
    conn_params_init();

    set_param_00();
    set_param_01();
    set_param_10();
    set_param_11();
    set_param_ref();
    bmm150_full_init_all();
    set_forced();
    timers_init();

    advertising_start();

    for (;;)
    {
        idle_state_handle();
    }
}
