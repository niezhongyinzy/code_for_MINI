# BMM150 Magnetometer Array Firmware (nRF52832)

Firmware for a 32-sensor BMM150 magnetometer array with a separate reference sensor. The nRF52832 samples all sensors at 4 Hz and transmits the data over Bluetooth Low Energy.

## Hardware

| Item | Details |
|---|---|
| MCU | nRF52832, SoftDevice S132 v7.0.1 |
| Sensor array | 32 × BMM150 via a TCA9548A I²C multiplexer (8 channels × 4 sensors) |
| Array bus | TWIM0, SCL = P0.25, SDA = P0.27 |
| Reference sensor | 1 × BMM150 on TWIM1, SCL = P0.29, SDA = P0.28 |

## Requirements

- nRF5 SDK 17.0.0 (not included)
- Keil MDK with ARM Compiler 5.06

## Repository Structure

```
drive/                                   BMM150 driver
examples/ble_peripheral/ble_app_uart/
├── main.c                               Application
└── pca10040/s132/
    ├── config/sdk_config.h              SDK configuration
    └── arm5_no_packs/                   Keil project
```

Copy `drive/` and `examples/` into the SDK root before building.