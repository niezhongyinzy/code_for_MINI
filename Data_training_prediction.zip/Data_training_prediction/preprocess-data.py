import pandas as pd
from sklearn.preprocessing import StandardScaler
import numpy as np
import pickle
import os

train_data_path = "data/train/train.xlsx"
val_data_path = "data/valid/valid.xlsx"

PROCESSED_DATA_DIR = "model"
os.makedirs(PROCESSED_DATA_DIR, exist_ok=True)

scaler_path = os.path.join(PROCESSED_DATA_DIR, 'scaler.pkl')
processed_data_path = os.path.join(PROCESSED_DATA_DIR, 'data.npz')


train_df = pd.read_excel(train_data_path)
val_df = pd.read_excel(val_data_path)

drop_columns = ['Channel 97', 'Channel 98', 'Channel 99', 'PRESSURE']
X_train = train_df.drop(columns=drop_columns)
y_train = train_df['PRESSURE']
X_val = val_df.drop(columns=drop_columns)
y_val = val_df['PRESSURE']

scaler = StandardScaler()
scaler.fit(X_train)


with open(scaler_path, 'wb') as f:
    pickle.dump(scaler, f)

X_train_scaled = scaler.transform(X_train)
X_val_scaled = scaler.transform(X_val)


np.savez_compressed(
    processed_data_path,
    X_train=X_train_scaled,
    y_train=y_train.values,
    X_val=X_val_scaled,
    y_val=y_val.values
)
print(f"Processed data arrays saved to: {processed_data_path}")
print("\n--- Preprocessing complete! ---")

