# Pressure Prediction Scripts

Python scripts for data preprocessing, ResMLP model training, and real-time prediction from the BMM150 sensor array.

## Requirements

Python 3 with `numpy`, `pandas`, `openpyxl`, `scikit-learn`, `torch`, `matplotlib`, `tqdm`, `PyQt5`, `pyqtgraph`, `bleak`.

## Files

| File | Description |
|---|---|
| `preprocess-data.py` | Standardizes the training and validation data |
| `Res_MLP.py` | Trains the ResMLP model (requires a CUDA GPU) |
| `pred_map_alldata_BLE-qt-binary-4.py` | Receives sensor data over BLE and displays real-time predictions |

## Usage

Run from this directory, in order:

```
python preprocess-data.py      # data/train/train.xlsx, data/valid/valid.xlsx -> model/scaler.pkl, model/data.npz
python Res_MLP.py              # model/data.npz -> model/RESMLP_bs2048/best_model.pth
python pred_map_alldata_BLE-qt-binary-4.py
```

Set `BLE_DEVICE_ADDRESS` in the prediction script to the address of your device. Real-time results are saved to `output/`.