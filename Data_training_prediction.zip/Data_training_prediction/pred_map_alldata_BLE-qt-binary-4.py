import sys
import os
import asyncio
import threading
import queue
import time
from datetime import datetime
import numpy as np
import csv
import pickle
import torch
import torch.nn as nn
import pandas as pd

from PyQt5 import QtWidgets, QtCore, QtGui
import pyqtgraph as pg
from bleak import BleakClient
import warnings
start_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

BLE_DEVICE_ADDRESS = "C1:EC:A5:8D:51:AB"

BLE_TX_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

MODEL_DIR = 'model/' 
SAVE_DIR = 'output/'
os.makedirs(SAVE_DIR, exist_ok=True)

OUTPUT_FULL_CSV = os.path.join(SAVE_DIR, f'data_log_{start_timestamp}.csv')
ALL_PRED_FILENAME = os.path.join(SAVE_DIR, f"realtime_predictions_{start_timestamp}.csv")
SCALER_FILENAME = os.path.join(MODEL_DIR, 'scaler.pkl')
MODEL_FILENAME = os.path.join(MODEL_DIR, 'RESMLP_bs2048', 'best_model.pth')

hparams = {
    "hidden_dim": 256,
    "num_blocks": 3,
    "dropout_rate": 0.1
}
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

POST_OFFSET = 0
POST_SCALE = 1
PLOT_DATA_LENGTH = 300
PLOT_Y_LIMIT_PRED = (-5, 30)

VALID_SENSOR_COORDINATES = [
    (0, 1), (0, 2), (0, 3), (0, 4), (1, 0), (1, 1), (1, 2), (1, 3),
    (2, 0), (2, 1), (2, 2), (2, 3), (3, 0), (3, 1), (3, 2), (3, 3),
    (4, 0), (4, 1), (4, 2), (4, 3), (5, 1), (5, 2), (5, 3), (5, 4),
    (1, 4), (2, 4), (3, 4), (4, 4), (1, 5), (2, 5), (3, 5), (4, 5)
]
SENSOR_ROWS = np.array([c[0] for c in VALID_SENSOR_COORDINATES])
SENSOR_COLS = np.array([c[1] for c in VALID_SENSOR_COORDINATES])

class ResNetBlock(nn.Module):
    def __init__(self, size: int, dropout_rate: float):
        super().__init__()
        self.layer1 = nn.Linear(size, size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout_rate)
        self.layer2 = nn.Linear(size, size)
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        out = self.layer1(x)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.layer2(out)
        out += residual
        return out

class ResMLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, num_blocks: int, output_dim: int, dropout_rate: float):
        super().__init__()
        self.input_layer = nn.Linear(input_dim, hidden_dim)
        self.blocks = nn.Sequential(*[ResNetBlock(hidden_dim, dropout_rate) for _ in range(num_blocks)])
        self.output_layer = nn.Linear(hidden_dim, output_dim)
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.input_layer(x) 
        x = self.blocks(x)
        x = self.output_layer(x)
        return x

class BLEDataReceiver:
    def __init__(self, address, uuid, data_queue, stop_event):
        self.address = address
        self.uuid = uuid
        self.data_queue = data_queue
        self.stop_event = stop_event
        self.buffer = bytearray()
        self.PACKET_SIZE = 198 

    def notification_handler(self, sender, data):
        self.buffer.extend(data)
        while len(self.buffer) >= self.PACKET_SIZE:
            packet = self.buffer[:self.PACKET_SIZE]
            arrival_time = time.time() 
           
            self.data_queue.put((arrival_time, packet))
            
            self.buffer = self.buffer[self.PACKET_SIZE:]

    async def run(self):
        while not self.stop_event.is_set():
            try:
                print(f"[BLE] Connecting to {self.address}...")
                async with BleakClient(self.address, timeout=10.0) as client:
                    if not client.is_connected: continue
                    print(f"[BLE] Connected! MTU: {client.mtu_size}")
                    await client.start_notify(self.uuid, self.notification_handler)
                    while not self.stop_event.is_set():
                        if not client.is_connected: break
                        await asyncio.sleep(0.1)
                    await client.stop_notify(self.uuid)
                    print("[BLE] Disconnected.")
                    return
            except Exception as e:
                print(f"[BLE] Error: {e}. Retrying in 2s...")
                await asyncio.sleep(2.0)

def ble_thread_entry(receiver):
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(receiver.run())

class RealTimePlotter(QtWidgets.QMainWindow):
    def __init__(self, data_queue, stop_event):
        super().__init__()
        self.data_queue = data_queue
        self.stop_event = stop_event
        
        self.loop_count = 0
        self.latest_raw_data_flat = None 
        self.tare_snapshot = np.zeros(96) 
        self.is_tared = False
        
        self.fps = 0.0
        self.last_fps_time = time.time()
        self.fps_counter = 0
        
        self.pred_history = np.zeros(PLOT_DATA_LENGTH)
        self.ptr = 0
        
        self.load_model()
        self.scaler_feature_names = [f"Channel {i+1}" for i in range(96)]
        
        self.f_csv = open(OUTPUT_FULL_CSV, 'w', newline='')
        self.writer = csv.writer(self.f_csv)
        header = ['Timestamp', 'Frame']
        for i in range(32): 
            for x in 'XYZ': header.append(f'S{i}_{x}')
        for x in 'XYZ': header.append(f'Ref_{x}')
        self.writer.writerow(header)

        self.f_pred = open(ALL_PRED_FILENAME, 'w', newline='')
        self.writer_pred = csv.writer(self.f_pred)
        self.writer_pred.writerow(['Frame', 'Raw_Output', 'Processed_Output'])
        
        self.init_ui()
        
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_loop)
        self.timer.start(10) 

    def load_model(self):
        print("Loading AI Model...")
        try:
            with open(SCALER_FILENAME, 'rb') as f: 
                self.scaler = pickle.load(f)
            
            self.model = ResMLP(input_dim=96, output_dim=1, **hparams).to(DEVICE)
            state_dict = torch.load(MODEL_FILENAME, map_location=DEVICE)
            self.model.load_state_dict(state_dict)
            self.model.eval()
            print("Model loaded successfully on", DEVICE)
        except Exception as e:
            print(f"Error loading model: {e}")
            self.model = None

    def init_ui(self):
        self.setWindowTitle("Real-time AI Sensor System")
        self.resize(1400, 800) 

        self.central_widget = QtWidgets.QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QtWidgets.QHBoxLayout(self.central_widget)
        self.main_layout.setSpacing(10)
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        
        self.central_widget.setObjectName("central")
        self.central_widget.setStyleSheet("#central { background-color: #E6E6E6; }")

        self.left_panel = QtWidgets.QWidget()
        self.left_layout = QtWidgets.QVBoxLayout(self.left_panel)
        self.left_layout.setContentsMargins(0,0,0,0)
        
        self.pred_plot_widget = pg.PlotWidget(background='w', title="<b>Real-time Prediction</b>")
        self.pred_plot_widget.setYRange(*PLOT_Y_LIMIT_PRED)
        self.pred_plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.pred_plot_widget.setLabel('left', 'Pressure', units='g')
        self.pred_plot_widget.setLabel('bottom', 'Time Steps')
        
        self.curve = self.pred_plot_widget.plot(pen=pg.mkPen(color='#c48d7b', width=2)) 
        
        self.lbl_value = QtWidgets.QLabel("Waiting...")
        self.lbl_value.setStyleSheet("""
            background-color: white; 
            border: 1px solid #ccc; 
            border-radius: 5px;
            font-size: 24px; 
            font-weight: bold; 
            color: #333; 
            padding: 10px;
        """)
        self.lbl_value.setAlignment(QtCore.Qt.AlignCenter)

        self.left_layout.addWidget(self.pred_plot_widget, stretch=1)
        self.left_layout.addWidget(self.lbl_value, stretch=0)
        
        self.right_panel = QtWidgets.QWidget()
        self.right_layout = QtWidgets.QGridLayout(self.right_panel)
        self.right_layout.setSpacing(5)
        self.right_layout.setContentsMargins(0, 0, 0, 0)

        self.morandi_colors_list = [
            (111, 142, 163, 255),
            (255, 255, 255, 255),
            (196, 141, 123, 255)
        ]
        pos = np.array([0.0, 0.5, 1.0])
        color_np = np.array([list(c) for c in self.morandi_colors_list], dtype=np.ubyte)
        self.morandi_cmap = pg.ColorMap(pos, color_np)

        self.plots = [] 
        self.img_items = []
        titles = ['X-Axis', 'Y-Axis', 'Z-Axis', 'Magnitude']
        
        
        first_plot_item = None
        
        for i in range(4):
            pw = pg.PlotWidget(background='w')
            p = pw.getPlotItem()
            p.setTitle(titles[i])
            p.setAspectLocked(True)
            p.hideAxis('bottom'); p.hideAxis('left')
            p.invertY(True); p.setDefaultPadding(0.0)
            p.setMouseEnabled(x=False, y=False); p.setMenuEnabled(False)
            
            img = pg.ImageItem()
            img.setLookupTable(self.morandi_cmap.getLookupTable(0.0, 1.0, 256))
            img.setRect(QtCore.QRectF(0, 0, 6, 6))
            dummy_data = np.zeros((6, 6))
            img.setImage(dummy_data, autoLevels=False, levels=(-1, 1))
            p.addItem(img)
            
            if i == 0:
                first_plot_item = p
            else:
                p.setXLink(first_plot_item); p.setYLink(first_plot_item)

            row = i // 2
            col = i % 2
            self.right_layout.addWidget(pw, row, col)
            self.plots.append(p); self.img_items.append(img)

        self.lut = pg.HistogramLUTWidget()
        self.lut.setBackground('#E6E6E6') 
        self.right_layout.addWidget(self.lut, 0, 2, 2, 1)
        self.lut.setFixedWidth(80)
        self.lut.setImageItem(self.img_items[0])
        self.lut.gradient.setColorMap(self.morandi_cmap) 
        self.lut.plot.setVisible(False); self.lut.gradient.hide(); self.lut.axis.setPen(None)
        
        grad = QtGui.QLinearGradient(0, 0, 0, 1)
        grad.setCoordinateMode(QtGui.QLinearGradient.ObjectBoundingMode)
        grad.setColorAt(0.0, QtGui.QColor(*self.morandi_colors_list[0])) 
        grad.setColorAt(0.5, QtGui.QColor(*self.morandi_colors_list[1]))
        grad.setColorAt(1.0, QtGui.QColor(*self.morandi_colors_list[2]))
        
        self.lut.region.setBrush(QtGui.QBrush(grad))
        self.lut.region.setHoverBrush(QtGui.QBrush(grad))
        for line in self.lut.region.lines: line.setPen(None); line.setHoverPen(None)

        self.control_panel = QtWidgets.QWidget()
        self.control_layout = QtWidgets.QHBoxLayout(self.control_panel)
        self.control_layout.setContentsMargins(10, 5, 10, 5)
        
        btn_style = "QPushButton {background-color: #f0f0f0; border: 1px solid #bbb; border-radius: 4px; padding: 6px 20px; font-size: 14px;} QPushButton:hover {background-color: #e0e0e0;} QPushButton:pressed {background-color: #d0d0d0;}"
        
        self.btn_tare = QtWidgets.QPushButton("去皮 (Tare)"); self.btn_tare.setStyleSheet(btn_style)
        self.btn_tare.clicked.connect(self.do_tare)
        self.btn_reset = QtWidgets.QPushButton("复位 (Reset)"); self.btn_reset.setStyleSheet(btn_style)
        self.btn_reset.clicked.connect(self.reset_tare)
        self.lbl_status = QtWidgets.QLabel("Status: Raw"); self.lbl_status.setStyleSheet("font-size: 12px; color: #555; margin-left: 15px;")
        
        self.control_layout.addWidget(self.btn_tare); self.control_layout.addWidget(self.btn_reset); self.control_layout.addWidget(self.lbl_status); self.control_layout.addStretch()
        self.right_layout.addWidget(self.control_panel, 2, 0, 1, 3)
        
        self.right_layout.setColumnStretch(0, 1); self.right_layout.setColumnStretch(1, 1); self.right_layout.setColumnStretch(2, 0)
        self.right_layout.setRowStretch(0, 1); self.right_layout.setRowStretch(1, 1); self.right_layout.setRowStretch(2, 0)

        self.main_layout.addWidget(self.left_panel, stretch=2) 
        self.main_layout.addWidget(self.right_panel, stretch=3)

    def do_tare(self):
        if self.latest_raw_data_flat is not None:
            self.tare_snapshot = self.latest_raw_data_flat.copy()
            self.is_tared = True
            self.lbl_status.setText("Status: Tared")
            self.lbl_status.setStyleSheet("font-size: 12px; color: #c48d7b; font-weight: bold; margin-left: 15px;")

    def reset_tare(self):
        self.tare_snapshot = np.zeros(96)
        self.is_tared = False
        self.lbl_status.setText("Status: Raw")
        self.lbl_status.setStyleSheet("font-size: 12px; color: #555; margin-left: 15px;")

    def force_reset_view(self):
        for p in self.plots: p.autoRange(padding=0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.force_reset_view()

    def update_loop(self):
        try:
            import struct
            
            batch_data = []
            while not self.data_queue.empty():
                try:
                    batch_data.append(self.data_queue.get_nowait())
                except queue.Empty: break
            
            curr_time = time.time()
            if curr_time - self.last_fps_time >= 1.0:
                self.fps = self.fps_counter / (curr_time - self.last_fps_time)
                self.fps_counter = 0
                self.last_fps_time = curr_time
                if not batch_data:
                    self.setWindowTitle(f"Real-time AI Sensor | FPS: {self.fps:.1f} (No Data)")

            if not batch_data: return

            latest_grids = None
            
            for (arrival_time, packet_bytes) in batch_data:
                self.loop_count += 1
                self.fps_counter += 1
                
                try:
                    if len(packet_bytes) != 198: 
                        print(f"Error: Wrong packet size {len(packet_bytes)}")
                        continue
                    
                    all_ints = struct.unpack('<99h', packet_bytes)
                    all_data = np.array(all_ints, dtype=np.float32) / 10.0
                    
                    if self.loop_count % 100 == 0:
                        print(f"[Debug] Frame {self.loop_count} Raw Sample: {all_data[:5]}")

                    raw_96 = all_data[:96]
                    self.latest_raw_data_flat = raw_96
                    ref_3 = all_data[96:]
                    
                    raw_output = 0.0
                    processed_output = 0.0
                    
                    try:
                        if self.model is not None:
                            df_input = pd.DataFrame([raw_96], columns=self.scaler_feature_names)
                            
                            x_scaled = self.scaler.transform(df_input)
                            
                            x_tensor = torch.tensor(x_scaled, dtype=torch.float32).to(DEVICE)
                            
                            with torch.no_grad():
                                raw_output = self.model(x_tensor).cpu().numpy().item()
                            
                            processed_output = (raw_output + POST_OFFSET) * POST_SCALE
                            
                            self.pred_history[:-1] = self.pred_history[1:]
                            self.pred_history[-1] = processed_output
                            
                    except Exception as e_ai:
                        if self.loop_count % 10000 == 0:
                            print(f"[AI Error] {e_ai}")
                    
                    self.writer_pred.writerow([self.loop_count, raw_output, processed_output])
                    
                    dt_object = datetime.fromtimestamp(arrival_time)
                    time_str = dt_object.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
                    
                    
                    sensors_data_list = raw_96.tolist() 
                    ref_data_list = ref_3.tolist()
                    
                    row = [time_str, self.loop_count] + sensors_data_list + ref_data_list
                    
                    self.writer.writerow(row)
                    
                    sensors_raw = raw_96.reshape(-1, 3)
                    xs_r, ys_r, zs_r = sensors_raw[:, 0], sensors_raw[:, 1], sensors_raw[:, 2]
                    
                    display_96 = raw_96 - self.tare_snapshot
                    sensors_display = display_96.reshape(-1, 3)
                    xs = sensors_display[:, 0]; ys = sensors_display[:, 1]; zs = sensors_display[:, 2]
                    mags = np.sqrt(xs**2 + ys**2 + zs**2)
                    
                    grid_x = np.full((6, 6), np.nan); grid_x[SENSOR_ROWS, SENSOR_COLS] = xs
                    grid_y = np.full((6, 6), np.nan); grid_y[SENSOR_ROWS, SENSOR_COLS] = ys
                    grid_z = np.full((6, 6), np.nan); grid_z[SENSOR_ROWS, SENSOR_COLS] = zs
                    grid_m = np.full((6, 6), np.nan); grid_m[SENSOR_ROWS, SENSOR_COLS] = mags
                    
                    latest_grids = [grid_x, grid_y, grid_z, grid_m]
                    
                except Exception as e_parse:
                    print(f"[Parse Error] {e_parse}")
                    continue

            try:
                self.curve.setData(self.pred_history)
                self.lbl_value.setText(f"{self.pred_history[-1]:.3f} ")
            except: pass
            
            if latest_grids:
                actual_max = 0
                for g in latest_grids:
                    m = np.nanmax(np.abs(g))
                    if m > actual_max: actual_max = m
                target_g_max = max(actual_max, 40.0)

                for i, img in enumerate(self.img_items):
                    img.setImage(latest_grids[i], autoLevels=False, levels=(-target_g_max, target_g_max))
                
                self.setWindowTitle(f"Real-time AI Sensor | FPS: {self.fps:.1f}")

        except Exception as e:
            print(f"[Main Loop Critical Error] {e}")

            self.curve.setData(self.pred_history)
            self.lbl_value.setText(f"{self.pred_history[-1]:.3f} g")
            
            if latest_grids:
                actual_max = 0
                for g in latest_grids:
                    m = np.nanmax(np.abs(g))
                    if m > actual_max: actual_max = m
                target_g_max = max(actual_max, 40.0)

                for i, img in enumerate(self.img_items):
                    img.setImage(latest_grids[i], autoLevels=False, levels=(-target_g_max, target_g_max))
                
                self.setWindowTitle(f"Real-time AI Sensor | FPS: {self.fps:.1f}")

        except Exception as e:
            print(f"Update Loop Error: {e}")

    def closeEvent(self, event):
        self.stop_event.set()
        self.f_csv.close()
        self.f_pred.close()
        event.accept()

if __name__ == '__main__':
    data_queue = queue.Queue()
    stop_event = threading.Event()
    
    receiver = BLEDataReceiver(BLE_DEVICE_ADDRESS, BLE_TX_UUID, data_queue, stop_event)
    t = threading.Thread(target=ble_thread_entry, args=(receiver,))
    t.daemon = True
    t.start()

    app = QtWidgets.QApplication(sys.argv)
    window = RealTimePlotter(data_queue, stop_event)
    window.show()
    
    import signal
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    sys.exit(app.exec_())
