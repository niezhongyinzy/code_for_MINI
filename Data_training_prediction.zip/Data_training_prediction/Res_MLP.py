import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import matplotlib.pyplot as plt
from tqdm import trange
import numpy as np
import os
from torch.optim import lr_scheduler
import multiprocessing
from torch.cuda.amp import GradScaler
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts


class ResNetBlock(nn.Module):
    def __init__(self, size: int, dropout_rate: float):
        super().__init__()
        self.layer1 = nn.Linear(size, size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout_rate)
        self.layer2 = nn.Linear(size, size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        out = self.layer1(x)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.layer2(out)
        
        out += residual
        return out

class ResMLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, num_blocks: int, output_dim: int, dropout_rate: float):
        super().__init__()
        self.input_layer = nn.Linear(input_dim, hidden_dim)
        
        self.blocks = nn.Sequential(
            *[ResNetBlock(hidden_dim, dropout_rate) for _ in range(num_blocks)]
        )
        
        self.output_layer = nn.Linear(hidden_dim, output_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.input_layer(x)
        x = self.blocks(x)
        x = self.output_layer(x)
        return x
def evaluate_and_plot_model(model, X_val, y_val, epoch, hparams, save_dir):
    print(f"\n--- Evaluating and plotting model at Epoch {epoch+1} ---")
    model.eval()
    with torch.no_grad():
        device = next(model.parameters()).device
        X_val_on_device = X_val.to(device)
        
        y_pred_val = model(X_val_on_device)
        
        y_pred_val_cpu = y_pred_val.detach().cpu().numpy()
        
        if isinstance(y_val, torch.Tensor):
            y_val_cpu = y_val.detach().cpu().numpy()
        else:
            y_val_cpu = y_val

    mae = mean_absolute_error(y_val_cpu, y_pred_val_cpu)
    mse = mean_squared_error(y_val_cpu, y_pred_val_cpu)
    r2 = r2_score(y_val_cpu, y_pred_val_cpu)

    print(f"Validation MAE: {mae:.4f}")
    print(f"Validation MSE: {mse:.4f}")
    print(f"Validation R2 Score: {r2:.4f}")

    num_samples = len(y_val_cpu)
    sample_indices = range(num_samples)
    
    plt.figure(figsize=(12, 5))
    plt.scatter(sample_indices, y_val_cpu, label='True Value', alpha=0.4, s=3)
    plt.scatter(sample_indices, y_pred_val_cpu, label='Predicted Value', alpha=0.7, s=3)
    plt.xlabel('Sample Index (Validation Set)')
    plt.ylabel('Pressure')
    title = (f'Epoch {epoch+1} (R2={r2:.4f}) | bs={hparams["bs"]}, lr={hparams["lr"]}, '
             f'l2={hparams["l2"]}, drop={hparams["dropout_rate"]}')
    plt.title(title)
    plt.legend()
    plt.grid(True)
    
    plots_dir = os.path.join(save_dir, "epoch_plots")
    os.makedirs(plots_dir, exist_ok=True)
    plot_save_path = os.path.join(plots_dir, f'plot_epoch{epoch+1}.png')
    plt.savefig(plot_save_path)
    plt.show()

if __name__ == '__main__':
    multiprocessing.freeze_support()

    hparams = {
        "bs": 2048,
        "lr": 2e-5,
        "l2": 1e-4,
        "num_workers": 4,
        "num_epochs": 8000,
        "patience": 600,
        "model_type": "ResMLP",
        "hidden_dim": 256,
        "num_blocks":3,
        "dropout_rate": 0.1
    }
    
    T_0 = 100
    T_mult = 1
    eta_min = 1e-7

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")
    output_base_dir = f"model/RESMLP_bs{hparams['bs']}"
    os.makedirs(output_base_dir, exist_ok=True)
    PROCESSED_DATA_DIR = "model"
    processed_data_path = os.path.join(PROCESSED_DATA_DIR, 'data.npz')
    with np.load(processed_data_path) as data:
        X_train_scaled = data['X_train']
        y_train_values = data['y_train']
        X_val_scaled = data['X_val']
        y_val_values = data['y_val']

    device = torch.device('cuda')
    
    X_train_gpu = torch.tensor(X_train_scaled, dtype=torch.float32).to(device)
    y_train_gpu = torch.tensor(y_train_values, dtype=torch.float32).view(-1, 1).to(device)
    X_val_gpu = torch.tensor(X_val_scaled, dtype=torch.float32).to(device)
    y_val_gpu = torch.tensor(y_val_values, dtype=torch.float32).view(-1, 1).to(device)
    
    print("数据已全部加载至 GPU 显存！")

    train_dataset = TensorDataset(X_train_gpu, y_train_gpu)
    val_dataset = TensorDataset(X_val_gpu, y_val_gpu)
    
    train_loader = DataLoader(train_dataset, batch_size=hparams["bs"], shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=hparams["bs"]*2, shuffle=False, num_workers=0)

    
    input_dimension = X_train_scaled.shape[1]
    print(f"Data prepared. Input dimension for the model: {input_dimension}")
    model = ResMLP(
        input_dim=input_dimension, 
        hidden_dim=hparams["hidden_dim"], 
        num_blocks=hparams["num_blocks"], 
        output_dim=1, 
        dropout_rate=hparams["dropout_rate"]
    ).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=hparams["lr"], weight_decay=hparams["l2"])
    scheduler = CosineAnnealingWarmRestarts(optimizer, T_0=T_0, T_mult=T_mult, eta_min=eta_min)
    scaler = torch.amp.GradScaler('cuda')
    criterion = nn.MSELoss()
    
    print(f"--- Starting Final MLP Training ---")
    print(f"Hyperparameters: {hparams}")
    
    best_val_loss = float('inf')
    epochs_no_improve = 0
    best_model_path = os.path.join(output_base_dir, 'best_model.pth')

    for epoch in trange(hparams["num_epochs"], desc="Training MLP"):
        model.train()
        train_loss_accum = 0.0
        for inputs, targets in train_loader:
            
            with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
                outputs = model(inputs)
                loss = criterion(outputs, targets)
            
            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            train_loss_accum += loss.item() * inputs.size(0)
        
        avg_train_loss = train_loss_accum / len(train_loader.dataset)

        model.eval()
        val_loss_accum = 0.0
        with torch.no_grad():
            for inputs_val, targets_val in val_loader:
                inputs_val = inputs_val.to(device, non_blocking=True)
                targets_val = targets_val.to(device, non_blocking=True)
                with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
                    outputs_val = model(inputs_val)
                    loss_val = criterion(outputs_val, targets_val)
                val_loss_accum += loss_val.item() * inputs_val.size(0)
        avg_val_loss = val_loss_accum / len(val_dataset)
        
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            epochs_no_improve = 0
            
            torch.save(model.state_dict(), best_model_path)
            
            checkpoints_dir = os.path.join(output_base_dir, "checkpoints")
            os.makedirs(checkpoints_dir, exist_ok=True)
            current_lr = optimizer.param_groups[0]['lr']
            checkpoint_filename = (f"epoch-{epoch+1:04d}_loss-{best_val_loss:.4f}_lr-{current_lr:.2e}.pth")
            checkpoint_path = os.path.join(checkpoints_dir, checkpoint_filename)
            torch.save(model.state_dict(), checkpoint_path)
            
            print(f"\nEpoch {epoch+1}: Val loss improved to {best_val_loss:.4f}. Train Loss: {avg_train_loss:.4f}. Best model updated and checkpoint saved.")
            
            evaluate_and_plot_model(model, X_val_gpu, y_val_gpu, epoch, hparams, output_base_dir)
        else:
            epochs_no_improve += 1

        if epochs_no_improve >= hparams["patience"]:
            print(f"\nEarly stopping triggered at epoch {epoch+1}.")
            break
            
        scheduler.step()

    print("\n--- Training Finished ---")
    print(f"Best validation loss achieved: {best_val_loss:.4f}")
